//>>built
define("dojo/nls/mobile-ui-layer_ROOT",{"dijit/form/nls/ComboBox":{previousMessage:"Previous choices",nextMessage:"More choices"}});
//@ sourceMappingURL=mobile-ui-layer_ROOT.js.map